<?php 
class Kalkulator extends CI_Controller{
	public function index(){
		$this->load->view('kalkulator/index');
	}

	public function hasil_hitung(){

		// Mengecek masukan dari form
		$angka1 = $this->input->post('angka1');
		$angka2 = $this->input->post('angka2');
		$pilih_hitung = $this->input->post('pilih_hitung');

		$hasil_hitung = 0;
		// Mengeck Perhitungan yang di minta
		if ($pilih_hitung == "+"){
			$hasil_hitung = $angka1 + $angka2;
		}else if ( $pilih_hitung == "-"){
			$hasil_hitung = $angka1 - $angka2;
		}else if ( $pilih_hitung == "*"){
			$hasil_hitung = $angka1 * $angka2;
		}else if ( $pilih_hitung == "/"){
			$hasil_hitung = $angka1 / $angka2;
		}

		// deklarasi data untuk di tampilkan di view
		$data['angka1'] = $angka1;
		$data['angka2'] = $angka2;
		$data['pilih_hitung'] = $pilih_hitung;
		$data['hasil_hitung'] = $hasil_hitung;

		// memanggil view untuk ditampilkan
		//$this->load->view('kalkulator/hasil_hitung',$data);

		

	}
}