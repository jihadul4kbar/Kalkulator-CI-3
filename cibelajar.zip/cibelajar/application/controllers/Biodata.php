<?php

class Biodata extends CI_Controller{

	function index(){
		$this->load->view('v_biodata');
	}

	function aritmatika(){
		echo "Fungsi Aritmatika <br>";
		$a = 10;
		$b = 20;

		echo "Penjumlahan =".$a+$b."<br>";
		echo "Pengurangan =".$a-$b."<br>";
		echo "Pembagian = ".$a/$b."<br>";
		echo "Perkalian = ".$a*$b."<br>";
	}
	
}

