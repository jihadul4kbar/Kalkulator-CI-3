<?php 

class Kalkulator2 extends CI_Controller{
	public function index(){
		$this->load->view('kalkulator2/index');
	}

	public function hitung(){
		// Mengambil Nilai yang dikirim 
		$angka1 = $this->input->post('angka1');
		$angka2 = $this->input->post('angka2');
		$pilih_hitung = $this->input->post('pilih_hitung');

		// mendeklarasikan variabel 
		$hasil_hitung = 0;
		// Memilih aksi yang akan dilakukan 
		if ($pilih_hitung == "+") {
			$hasil_hitung = $angka1 + $angka2;
		}else if ($pilih_hitung == "-"){
			$hasil_hitung = $angka1 - $angka2;
		}else if ($pilih_hitung == "*"){
			$hasil_hitung = $angka1 * $angka2;
		}else if ($pilih_hitung == "/"){
			$hasil_hitung = $angka1 / $angka2;
		}

		// mengirim hasil akhir ke dalam view
		$data['angka1'] = $angka1;
		$data['angka2'] = $angka2;
		$data['pilih_hitung'] = $pilih_hitung;
		$data['hasil_hitung'] = $hasil_hitung;

		// Melakukan pengecekan data yg di kirim 
		// echo "<pre>";
		// print_r($data);
		//var_dump($data);


		//memanggil view untuk ditampilkan 
		$this->load->view('kalkulator2/hasil_hitung',$data);

	}
}