<!DOCTYPE html>
<html>
<head>
	<title>Hasil Kalkulator</title>
</head>
<body>
	<h1>Hasil Kalkulator</h1>
	<p>Angka Pertama : <?php echo $angka1;?></p>
	<p>Angka Kedua : <?php echo $angka2;?></p>
	<p>Oprasi  : <?php echo $pilih_hitung;?></p>
	<p>Hasil   : <?php echo $hasil_hitung;?></p>

	<p>atau</p>
	<p> <?php echo $angka1." ".$pilih_hitung." ".$angka2." = ".$hasil_hitung;?></p>
</body>
</html>