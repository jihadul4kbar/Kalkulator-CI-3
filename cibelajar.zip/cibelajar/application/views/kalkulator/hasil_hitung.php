<!DOCTYPE html>
<html>
<head>
	<title>Hasil Hitung</title>
</head>
<body>
	<h1>Hasil Hitung</h1>
	<?php echo $angka1." ".$pilih_hitung." ".$angka2." = ".$hasil_hitung;?><br><br>
	<a href="<?php echo site_url('kalkulator/');?>"><< Kembali Menghitung</a>
</body>
</html>