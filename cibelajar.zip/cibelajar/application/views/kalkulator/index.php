<!DOCTYPE html>
<html>
<head>
	<title>Kalkulator</title>
</head>
<body>
<h1>Kalkulator</h1>
<form action="<?php echo base_url();?>index.php/kalkulator/hasil_hitung" method="POST">
	<input type="text" name="angka1" required=""><br><br>
	<input type="text" name="angka2" required=""><br><br>
	<select name="pilih_hitung">
		<option value="+">+</option>
		<option value="-">-</option>
		<option value="*">*</option>
		<option value="/">/</option>
	</select>
	<br><br>
	<input type="submit" value="Hitung">
</form>
</body>
</html>